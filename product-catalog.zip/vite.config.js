import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base "./" lets the build run from any sub-path (GitHub Pages project sites) or from a plain file server.
export default defineConfig({
  base: "./",
  plugins: [react()],
  build: { chunkSizeWarningLimit: 2500 },
});
