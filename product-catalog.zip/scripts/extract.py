#!/usr/bin/env python3
"""Extract the price list PDF into src/data/products.json (run once, offline).

Usage: python3 scripts/extract.py path/to/pricelist.pdf
Requires: pip install pdfplumber

Every figure is copied from the PDF text layer as a string, unchanged.
`brand`, `category` and `keySpec` are NOT in the PDF; they are derived from the
item name by the rules below and listed in `derivedFields` of the report.
"""
import sys, re, json, collections, pathlib
import pdfplumber

SRC = sys.argv[1] if len(sys.argv) > 1 else "pricelist.pdf"
OUT = pathlib.Path(__file__).resolve().parent.parent / "src" / "data"
NUM = re.compile(r"^\d+$")
DP_SEQ = ["0", "10", "20", "30", "40", "50"]

BRANDS = ["SUPER ASIA", "SUPER POWER", "WESTPOINT", "WEST POINT", "HAIER", "DAWLANCE", "PEL", "ROYAL", "TCL",
          "SAMSUNG", "KENWOOD", "HOMAGE", "CAMBRIDGE", "COMBRIDGE", "GREE", "BOSS", "BOSCH", "NASGAS", "HONDA",
          "CANNON", "SIGMA", "AUDIONIC", "ECOSTAR", "PHILIPS", "INFINIX", "PAK", "VIVO", "UNITED", "HP",
          "REDMI", "CANON", "PANASONIC", "HYUNDAI", "TECNO", "V-ON", "YAMAHA", "IMPRESS", "AARDEE", "OPPO",
          "INTAG", "LG", "ATLAS", "JAGUAR", "SONY", "QINGQI", "SUZUKI", "UNION STAR", "ECODOST", "SAK",
          "DELL", "LENOVO", "ASUS", "ACER", "APPLE", "XIAOMI", "REALME", "NOKIA", "ITEL", "NATIONAL", "ORIENT"]
BRAND_FIX = {"COMBRIDGE": "CAMBRIDGE", "WEST POINT": "WESTPOINT"}

CATS = [  # first match wins
    ("Used Items", r"^USED\b"),
    ("Firearms", r"PISTOL|SHOTGUN|RIFLE|\bARM\b"),
    ("Motorcycles & Vehicles", r"M/CYCLE|M/CYLCE|MOTOR ?CYCLE|MOTORCYCLE|\bMC\b|SCOOTY|ELECTRIC BIKE|RICKSHAW|\bBIKE\b|LOADER"),
    ("Air Conditioners", r"\bAC\b|AIR CONDITIONER|SPLIT"),
    ("Refrigerators & Freezers", r"\bREF\b|REFRIGERATOR|FREEZER|CHILLER"),
    ("Washing Machines", r"WASHING|W/MACHINE|WASHER|DRYER|SPINNER"),
    ("Water Heaters & Geysers", r"WATER HEATER|GEYSER"),
    ("Water Dispensers", r"DISPENSER"),
    ("Televisions", r"\bLED\b|\bTV\b|SMART TV|ANDROID|OLED|QLED|\bLCD\b"),
    ("Mobile Phones", r"MOBILE|PHONE|PHOME|SMARTPHONE|^(VIVO|REDMI|OPPO|TECNO|INFINIX|SAMSUNG GALAXY)\b"),
    ("Laptops & Computers", r"LAPTOP|NOTEBOOK|COMPUTER|\bPC\b|TABLET|\bIPAD\b"),
    ("Solar & Power", r"SOLAR|\bUPS\b|BATTERY|GENERATOR|STABILIZER"),
    ("Microwave Ovens", r"MICROWAVE|M/OVEN|\bOVEN\b"),
    ("Cooking Appliances", r"COOKING RANGE|HOB\b|COOKER|STOVE|BURNER|\bGAS\b|HOOD|\bGRILL\b"),
    ("Fans & Air Coolers", r"\bFAN\b|CELLING|CEILING|PEDESTAL|COOLER|EXHAUST"),
    ("Kitchen Appliances", r"BLENDER|JUICER|TOASTER|FOOD|CHOPPER|KETTLE|MIXER|GRINDER|FRYER|SANDWICH|PROCESSOR|COFFEE|EXPRESSO|TEA"),
    ("Home Care", r"\bIRON\b|VACUUM|VACCUM|\bSEWING\b|STEAMER"),
    ("Personal Care", r"TRIMMER|SHAVER|CLIPPER|EPILATOR|CURLER|HAIR|DRYER|STRAIGHTENER"),
    ("Heaters", r"HEATER|QUARTZ"),
    ("Camera & Audio", r"CAMERA|SPEAKER|HOME THEATER|SOUND|HEADPHONE|\bEARBUD|AUDIO"),
]
SPEC = re.compile(r"(\d+(?:\.\d+)?)\s?(TON|KG|CC|CFT|GALLONS?|LITERS?|LTRS?|INCH|GB|KVA|HP|BURNERS?|FT|KW|W)\b", re.I)


def derive_brand(name):
    up = " " + re.sub(r"[^A-Z0-9/\- ]", " ", name.upper()) + " "
    best = None
    for b in BRANDS:
        m = re.search(r"(?<![A-Z0-9])" + re.escape(b) + r"(?![A-Z0-9])", up)
        if m and (best is None or m.start() < best[0]):
            best = (m.start(), b)
    return BRAND_FIX.get(best[1], best[1]) if best else None


def derive_category(name):
    up = name.upper()
    for cat, rx in CATS:
        if re.search(rx, up):
            return cat
    return "Other"


def derive_spec(name):
    m = SPEC.search(name)
    return f"{m.group(1)} {m.group(2).upper()}" if m else None


rows, unparsed, per_page_expected = [], [], {}
prev = None
with pdfplumber.open(SRC) as pdf:
    npages = len(pdf.pages)
    for pn, page in enumerate(pdf.pages, 1):
        # Stream order keeps text that overflows from the name cell apart from the numeric cells.
        words = page.extract_words(use_text_flow=True)
        lines = collections.OrderedDict()
        for w in words:
            lines.setdefault(round(w["top"]), []).append(w)
        n_lines = 0
        for top, line in lines.items():
            t = [w["text"] for w in line]
            if t[:2] == ["Item", "Name"]:
                continue
            n_lines += 1
            if len(t) >= 10 and all(NUM.match(x) for x in t[-9:]):
                name, dp, vals = " ".join(t[:-9]), t[-9], t[-8:]
            elif len(t) >= 9 and all(NUM.match(x) for x in t[-8:]):
                # item name touches the DpOp cell, e.g. "1 TON10" -> name "1 TON", DpOp "10"
                exp = None if prev is None else DP_SEQ[(DP_SEQ.index(prev) + 1) % 6]
                last = t[-9]
                if exp is not None and last.endswith(exp) and len(last) > len(exp):
                    name, dp, vals = " ".join(t[:-9] + [last[: -len(exp)]]), exp, t[-8:]
                else:
                    unparsed.append({"page": pn, "text": " ".join(t)})
                    continue
            else:
                unparsed.append({"page": pn, "text": " ".join(t)})
                continue
            prev = dp
            rows.append({"page": pn, "name": name.strip(), "dp": dp, "v": vals})
        per_page_expected[pn] = n_lines

blocks, cur = [], None
for r in rows:
    if r["dp"] == "0" or cur is None or r["name"] != cur["name"]:
        cur = {"name": r["name"], "page": r["page"], "rows": []}
        blocks.append(cur)
    cur["rows"].append(r)

products, odd = [], []
for i, b in enumerate(blocks, 1):
    name = b["name"]
    m = re.match(r"^(\d{4,8})-", name)
    price = b["rows"][0]["v"][0]
    opts = []
    for r in b["rows"]:
        v = r["v"]
        opts.append({"downPaymentPercent": r["dp"], "price": v[0], "downPayment": v[1],
                     "total12": v[2], "total24": v[3], "total36": v[4],
                     "monthly12": v[5], "monthly24": v[6], "monthly36": v[7]})
    if len(opts) not in (1, 6):
        odd.append({"page": b["page"], "name": name, "rows": len(opts)})
    p = {"id": f"p{i:04d}", "name": name}
    if m:
        p["code"] = m.group(1)
    brand = derive_brand(name)
    if brand:
        p["brand"] = brand
    p["category"] = derive_category(name)
    spec = derive_spec(name)
    if spec:
        p["keySpec"] = spec
    p["price"] = price
    p["priceNum"] = int(price)
    p["hasEmi"] = any(o[k] != "0" for o in opts for k in ("monthly12", "monthly24", "monthly36"))
    p["options"] = opts
    p["sourcePage"] = b["page"]
    products.append(p)

OUT.mkdir(parents=True, exist_ok=True)
(OUT / "products.json").write_text(json.dumps(products, ensure_ascii=False, separators=(",", ":")))

per_page_parsed = collections.Counter(r["page"] for r in rows)
mismatch = [{"page": k, "linesInPdf": per_page_expected[k], "rowsParsed": per_page_parsed.get(k, 0)}
            for k in per_page_expected if per_page_expected[k] != per_page_parsed.get(k, 0)]
cats = collections.Counter(p["category"] for p in products)
report = {
    "pdfPages": npages,
    "dataLinesInPdf": sum(per_page_expected.values()),
    "rowsParsed": len(rows),
    "productsExtracted": len(products),
    "productsWithoutInstalments": sum(1 for p in products if not p["hasEmi"]),
    "productsWithoutBrand": sum(1 for p in products if "brand" not in p),
    "pagesWhereLineCountDiffers": mismatch,
    "unparsedRows": unparsed,
    "productsWithUnexpectedRowCount": odd,
    "categories": dict(cats.most_common()),
    "derivedFields": ["brand", "category", "keySpec", "code (leading 4-8 digit prefix of name)"],
}
(OUT / "parse-report.json").write_text(json.dumps(report, indent=2))
print(json.dumps({k: v for k, v in report.items() if k != "categories"}, indent=2))
print(json.dumps(report["categories"], indent=1))
