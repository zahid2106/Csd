/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "system-ui", "-apple-system", "Segoe UI", "Roboto", "Helvetica Neue", "Arial", "sans-serif"],
      },
      colors: {
        brand: { DEFAULT: "#17623f", dark: "#104a2f", tint: "#e3f0e8" },
        ink: { DEFAULT: "#1f2933", muted: "#5b6673" },
        line: "#dde1e6",
        page: "#f5f6f7",
      },
    },
  },
  plugins: [],
};
