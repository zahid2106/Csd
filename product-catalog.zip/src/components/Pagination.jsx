function pagesToShow(page, total) {
  const set = new Set([1, total, page, page - 1, page + 1]);
  const list = [...set].filter((n) => n >= 1 && n <= total).sort((a, b) => a - b);
  const out = [];
  list.forEach((n, i) => { if (i && n - list[i - 1] > 1) out.push("gap" + n); out.push(n); });
  return out;
}

export default function Pagination({ page, total, onPage }) {
  if (total <= 1) return null;
  const btn = "h-10 min-w-10 rounded border px-3 text-sm font-medium";
  return (
    <nav aria-label="Pagination" className="mt-6 flex flex-wrap items-center justify-center gap-2">
      <button type="button" className={`${btn} border-line bg-white hover:bg-page disabled:opacity-50`} disabled={page === 1} onClick={() => onPage(page - 1)}>Previous</button>
      {pagesToShow(page, total).map((n) =>
        typeof n === "string" ? <span key={n} className="px-1 text-ink-muted" aria-hidden="true">…</span> : (
          <button key={n} type="button" onClick={() => onPage(n)} aria-label={`Page ${n}`} aria-current={n === page ? "page" : undefined}
            className={`${btn} ${n === page ? "border-brand bg-brand text-white" : "border-line bg-white hover:bg-page"}`}>{n}</button>
        )
      )}
      <button type="button" className={`${btn} border-line bg-white hover:bg-page disabled:opacity-50`} disabled={page === total} onClick={() => onPage(page + 1)}>Next</button>
    </nav>
  );
}
