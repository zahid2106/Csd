import Highlight from "./Highlight.jsx";
import { money, plain } from "../lib/format.js";

// Lowest monthly figure on the no-down-payment row, e.g. "EMI from 5,526/month for 36 months".
export function emiSummary(p) {
  if (!p.hasEmi) return null;
  const o = p.options[0];
  const tiers = [[12, o.monthly12], [24, o.monthly24], [36, o.monthly36]].filter(([, v]) => v && v !== "0");
  if (!tiers.length) return null;
  const [months, amount] = tiers.reduce((a, b) => (Number(b[1]) < Number(a[1]) ? b : a));
  return `EMI from ${plain(amount)}/month for ${months} months`;
}

export default function ProductCard({ product: p, tokens, onOpen }) {
  const emi = emiSummary(p);
  return (
    <article className="flex flex-col rounded-md border border-line bg-white p-4">
      <h3 className="text-base font-semibold leading-snug text-ink break-words">
        <Highlight text={p.name} tokens={tokens} />
      </h3>
      <dl className="mt-2 space-y-1 text-sm">
        {p.code && (
          <div className="flex gap-2"><dt className="text-ink-muted">Code</dt><dd><Highlight text={p.code} tokens={tokens} /></dd></div>
        )}
        <div className="flex gap-2"><dt className="text-ink-muted">Category</dt><dd><Highlight text={p.category} tokens={tokens} /></dd></div>
        {p.brand && (
          <div className="flex gap-2"><dt className="text-ink-muted">Brand</dt><dd><Highlight text={p.brand} tokens={tokens} /></dd></div>
        )}
        {p.keySpec && (
          <div className="flex gap-2"><dt className="text-ink-muted">Size</dt><dd>{p.keySpec}</dd></div>
        )}
      </dl>
      <div className="mt-4 border-t border-line pt-3">
        <p className="text-xl font-bold text-ink">{money(p.price)}</p>
        {emi && <p className="mt-1 text-sm text-ink">{emi}</p>}
      </div>
      <button
        type="button"
        onClick={(e) => onOpen(p, e.currentTarget)}
        aria-label={`View details: ${p.name}`}
        className="mt-4 h-10 self-start rounded border border-brand px-4 text-sm font-medium text-brand hover:bg-brand hover:text-white"
      >
        View details
      </button>
    </article>
  );
}
