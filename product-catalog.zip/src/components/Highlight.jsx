import { highlightRanges } from "../lib/search.js";

export default function Highlight({ text, tokens }) {
  if (!text) return null;
  const ranges = highlightRanges(text, tokens);
  if (!ranges.length) return text;
  const parts = [];
  let pos = 0;
  ranges.forEach(([a, b], idx) => {
    if (a > pos) parts.push(text.slice(pos, a));
    parts.push(<mark key={idx}>{text.slice(a, b + 1)}</mark>);
    pos = b + 1;
  });
  if (pos < text.length) parts.push(text.slice(pos));
  return <>{parts}</>;
}
