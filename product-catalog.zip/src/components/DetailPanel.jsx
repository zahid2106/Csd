import { useEffect, useRef } from "react";
import { money, plain } from "../lib/format.js";

const th = "border-b border-line bg-page px-2 py-2 text-left text-xs font-semibold text-ink whitespace-nowrap";
const td = "border-b border-line px-2 py-2 text-sm tabular-nums whitespace-nowrap";

export default function DetailPanel({ product: p, onClose }) {
  const ref = useRef(null);
  const closeRef = useRef(null);

  useEffect(() => {
    closeRef.current?.focus();
    const onKey = (e) => {
      if (e.key === "Escape") { onClose(); return; }
      if (e.key !== "Tab") return;
      const nodes = ref.current.querySelectorAll('button, [href], input, select, [tabindex]:not([tabindex="-1"])');
      if (!nodes.length) return;
      const first = nodes[0], last = nodes[nodes.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = prev; };
  }, [onClose]);

  const facts = [
    ["Code", p.code], ["Category", p.category], ["Brand", p.brand], ["Size (from item name)", p.keySpec],
    ["Price list page", String(p.sourcePage)],
  ].filter(([, v]) => v);

  return (
    <div className="fixed inset-0 z-40">
      <div className="absolute inset-0 bg-ink/40" onClick={onClose} aria-hidden="true" />
      <aside ref={ref} role="dialog" aria-modal="true" aria-labelledby="panel-title"
        className="absolute inset-y-0 right-0 flex w-full max-w-2xl flex-col overflow-hidden border-l border-line bg-white shadow-lg">
        <header className="flex items-start justify-between gap-4 border-b border-line p-4">
          <h2 id="panel-title" className="text-lg font-semibold leading-snug break-words">{p.name}</h2>
          <button ref={closeRef} type="button" onClick={onClose} className="h-10 shrink-0 rounded border border-line px-4 text-sm font-medium hover:bg-page">Close</button>
        </header>
        <div className="flex-1 space-y-6 overflow-y-auto p-4">
          <section aria-labelledby="sec-price">
            <h3 id="sec-price" className="text-sm font-semibold text-ink-muted">Price</h3>
            <p className="mt-1 text-2xl font-bold">{money(p.price)}</p>
          </section>

          <section aria-labelledby="sec-info">
            <h3 id="sec-info" className="text-sm font-semibold text-ink-muted">Details</h3>
            <dl className="mt-2 divide-y divide-line rounded border border-line text-sm">
              {facts.map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4 px-3 py-2"><dt className="text-ink-muted">{k}</dt><dd className="text-right font-medium break-words">{v}</dd></div>
              ))}
            </dl>
          </section>

          <section aria-labelledby="sec-emi">
            <h3 id="sec-emi" className="text-sm font-semibold text-ink-muted">EMI options</h3>
            {p.hasEmi ? (
              <div className="mt-2 overflow-x-auto rounded border border-line">
                <table className="w-full border-collapse">
                  <caption className="sr-only">Down payment options with monthly instalment and total payable for 12, 24 and 36 months</caption>
                  <thead>
                    <tr>
                      <th scope="col" rowSpan="2" className={th}>Down payment</th>
                      <th scope="col" rowSpan="2" className={th}>Amount</th>
                      <th scope="colgroup" colSpan="2" className={`${th} text-center`}>12 months</th>
                      <th scope="colgroup" colSpan="2" className={`${th} text-center`}>24 months</th>
                      <th scope="colgroup" colSpan="2" className={`${th} text-center`}>36 months</th>
                    </tr>
                    <tr>
                      {[12, 24, 36].flatMap((m) => [
                        <th key={m + "m"} scope="col" className={th}>Monthly</th>,
                        <th key={m + "t"} scope="col" className={th}>Total</th>,
                      ])}
                    </tr>
                  </thead>
                  <tbody>
                    {p.options.map((o) => (
                      <tr key={o.downPaymentPercent}>
                        <th scope="row" className={`${td} text-left font-medium`}>{o.downPaymentPercent}%</th>
                        <td className={td}>{plain(o.downPayment)}</td>
                        <td className={`${td} font-semibold`}>{plain(o.monthly12)}</td><td className={td}>{plain(o.total12)}</td>
                        <td className={`${td} font-semibold`}>{plain(o.monthly24)}</td><td className={td}>{plain(o.total24)}</td>
                        <td className={`${td} font-semibold`}>{plain(o.monthly36)}</td><td className={td}>{plain(o.total36)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="mt-2 text-sm text-ink-muted">The price list shows 0 for every instalment column on this item, so no EMI figures are listed.</p>
            )}
            {p.hasEmi && <p className="mt-2 text-xs text-ink-muted">Figures are shown as printed in the price list. Total is the hire-purchase total; Monthly is the instalment.</p>}
          </section>
        </div>
      </aside>
    </div>
  );
}
