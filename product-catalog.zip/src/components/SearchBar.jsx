export default function SearchBar({ value, onChange }) {
  return (
    <div role="search" className="relative">
      <label htmlFor="search" className="sr-only">Search products by name, code, brand or category</label>
      <svg aria-hidden="true" className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-ink-muted" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="8.5" cy="8.5" r="5.5" /><path d="M13 13l4 4" strokeLinecap="round" />
      </svg>
      <input
        id="search"
        type="search"
        autoFocus
        autoComplete="off"
        spellCheck="false"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search by name, code, brand or category"
        className="h-14 w-full rounded-md border border-line bg-white pl-12 pr-12 text-base text-ink placeholder:text-ink-muted focus:border-brand [&::-webkit-search-cancel-button]:hidden"
      />
      {value && (
        <button
          type="button"
          onClick={() => { onChange(""); document.getElementById("search")?.focus(); }}
          aria-label="Clear search"
          className="absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded text-ink-muted hover:bg-page hover:text-ink"
        >
          <svg aria-hidden="true" className="h-5 w-5" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 5l10 10M15 5L5 15" /></svg>
        </button>
      )}
    </div>
  );
}
