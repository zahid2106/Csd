import { plain } from "../lib/format.js";

const field = "mt-1 h-10 w-full rounded border border-line bg-white px-2 text-sm text-ink focus:border-brand";
const label = "block text-sm font-medium text-ink";

export default function Filters({ facets, filters, setFilters, onReset, active }) {
  const set = (k) => (e) => setFilters({ ...filters, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  return (
    <form className="space-y-4" onSubmit={(e) => e.preventDefault()} aria-label="Filters">
      <div>
        <label htmlFor="f-cat" className={label}>Category</label>
        <select id="f-cat" value={filters.category} onChange={set("category")} className={field}>
          <option value="">All categories</option>
          {facets.categories.map(([c, n]) => <option key={c} value={c}>{c} ({plain(n)})</option>)}
        </select>
      </div>
      <div>
        <label htmlFor="f-brand" className={label}>Brand</label>
        <select id="f-brand" value={filters.brand} onChange={set("brand")} className={field}>
          <option value="">All brands</option>
          {facets.brands.map(([b, n]) => <option key={b} value={b}>{b} ({plain(n)})</option>)}
        </select>
      </div>
      <fieldset>
        <legend className={label}>Price range</legend>
        <div className="mt-1 grid grid-cols-2 gap-2">
          <div>
            <label htmlFor="f-min" className="sr-only">Minimum price</label>
            <input id="f-min" inputMode="numeric" placeholder="Min" value={filters.min} onChange={(e) => setFilters({ ...filters, min: e.target.value.replace(/\D/g, "") })} className="h-10 w-full rounded border border-line bg-white px-2 text-sm placeholder:text-ink-muted focus:border-brand" />
          </div>
          <div>
            <label htmlFor="f-max" className="sr-only">Maximum price</label>
            <input id="f-max" inputMode="numeric" placeholder="Max" value={filters.max} onChange={(e) => setFilters({ ...filters, max: e.target.value.replace(/\D/g, "") })} className="h-10 w-full rounded border border-line bg-white px-2 text-sm placeholder:text-ink-muted focus:border-brand" />
          </div>
        </div>
        <p className="mt-1 text-xs text-ink-muted">Listed prices: {plain(facets.minPrice)} to {plain(facets.maxPrice)}</p>
      </fieldset>
      <label className="flex items-center gap-2 text-sm font-medium text-ink">
        <input type="checkbox" checked={filters.emi} onChange={set("emi")} className="h-4 w-4 rounded border-line accent-brand" />
        EMI available
      </label>
      <button type="button" onClick={onReset} disabled={!active} className="h-10 w-full rounded border border-line bg-white text-sm font-medium text-ink hover:bg-page disabled:cursor-not-allowed disabled:text-ink-muted disabled:opacity-60">
        Reset filters
      </button>
    </form>
  );
}
