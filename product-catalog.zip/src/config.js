// Prefix shown before every amount. The PDF prints plain numbers with no currency symbol,
// so it is empty by default. Set e.g. "Rs. " if you want one.
export const CURRENCY_PREFIX = "";
export const PAGE_SIZE = 24;
export const SEARCH_DEBOUNCE_MS = 150;
