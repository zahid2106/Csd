import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import products from "./data/products.json";
import { PAGE_SIZE, SEARCH_DEBOUNCE_MS } from "./config.js";
import { plain } from "./lib/format.js";
import { buildIndex, runSearch, tokenize } from "./lib/search.js";
import SearchBar from "./components/SearchBar.jsx";
import Filters from "./components/Filters.jsx";
import ProductCard from "./components/ProductCard.jsx";
import DetailPanel from "./components/DetailPanel.jsx";
import Pagination from "./components/Pagination.jsx";

const EMPTY = { category: "", brand: "", min: "", max: "", emi: false };

function countBy(list, key) {
  const m = new Map();
  list.forEach((p) => p[key] && m.set(p[key], (m.get(p[key]) || 0) + 1));
  return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]));
}

export default function App() {
  const fuse = useMemo(() => buildIndex(products), []); // search index: { fuse, docs }
  const facets = useMemo(() => {
    const prices = products.map((p) => p.priceNum);
    return {
      categories: countBy(products, "category"),
      brands: countBy(products, "brand"),
      minPrice: Math.min(...prices),
      maxPrice: Math.max(...prices),
    };
  }, []);

  const [input, setInput] = useState("");
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState(EMPTY);
  const [sort, setSort] = useState("relevance");
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const opener = useRef(null);
  const top = useRef(null);

  useEffect(() => {
    const t = setTimeout(() => setQuery(input), SEARCH_DEBOUNCE_MS);
    return () => clearTimeout(t);
  }, [input]);

  useEffect(() => setPage(1), [query, filters, sort]);

  const tokens = useMemo(() => tokenize(query), [query]);
  const searching = tokens.length > 0;
  const effectiveSort = searching ? sort : sort === "relevance" ? "az" : sort;

  const results = useMemo(() => {
    const hits = searching ? runSearch(fuse, query) : null;
    let list = hits ? hits.map((h) => ({ p: products[h.i], score: h.score })) : products.map((p) => ({ p, score: 0 }));
    const min = filters.min === "" ? null : Number(filters.min);
    const max = filters.max === "" ? null : Number(filters.max);
    list = list.filter(({ p }) =>
      (!filters.category || p.category === filters.category) &&
      (!filters.brand || p.brand === filters.brand) &&
      (min === null || p.priceNum >= min) &&
      (max === null || p.priceNum <= max) &&
      (!filters.emi || p.hasEmi)
    );
    const byName = (a, b) => a.p.name.localeCompare(b.p.name, undefined, { numeric: true });
    if (effectiveSort === "az") list.sort(byName);
    else if (effectiveSort === "low") list.sort((a, b) => a.p.priceNum - b.p.priceNum || byName(a, b));
    else if (effectiveSort === "high") list.sort((a, b) => b.p.priceNum - a.p.priceNum || byName(a, b));
    else list.sort((a, b) => a.score - b.score || byName(a, b));
    return list.map((x) => x.p);
  }, [fuse, query, searching, filters, effectiveSort]);

  const pages = Math.max(1, Math.ceil(results.length / PAGE_SIZE));
  const current = Math.min(page, pages);
  const visible = results.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);
  const filtersActive = JSON.stringify(filters) !== JSON.stringify(EMPTY);

  const goPage = (n) => { setPage(n); top.current?.scrollIntoView({ block: "start" }); };
  const openPanel = (p, el) => { opener.current = el; setOpen(p); };
  const closePanel = useCallback(() => { setOpen(null); opener.current?.focus(); }, []);

  const reset = () => setFilters(EMPTY);
  const clearAll = () => { setInput(""); setQuery(""); setFilters(EMPTY); };

  return (
    <div className="min-h-screen">
      <header className="border-b border-line bg-white">
        <div className="mx-auto max-w-7xl px-4 py-4">
          <h1 className="text-xl font-semibold text-ink">Product Catalogue</h1>
          <p className="text-sm text-ink-muted">{plain(products.length)} products from the general price list</p>
        </div>
      </header>

      <div className="sticky top-0 z-30 border-b border-line bg-page">
        <div className="mx-auto max-w-7xl px-4 py-3">
          <SearchBar value={input} onChange={setInput} />
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-4 py-4 lg:grid lg:grid-cols-[256px_1fr] lg:gap-6">
        <div className="lg:block">
          <button type="button" onClick={() => setShowFilters((s) => !s)} aria-expanded={showFilters} aria-controls="filter-panel"
            className="mb-3 flex h-10 w-full items-center justify-between rounded border border-line bg-white px-4 text-sm font-medium lg:hidden">
            <span>Filters{filtersActive ? " (active)" : ""}</span><span aria-hidden="true">{showFilters ? "Hide" : "Show"}</span>
          </button>
          <div id="filter-panel" className={`${showFilters ? "block" : "hidden"} mb-4 rounded-md border border-line bg-white p-4 lg:sticky lg:top-24 lg:block`}>
            <h2 className="mb-4 hidden text-sm font-semibold text-ink lg:block">Filters</h2>
            <Filters facets={facets} filters={filters} setFilters={setFilters} onReset={reset} active={filtersActive} />
          </div>
        </div>

        <section aria-label="Results" ref={top} className="scroll-mt-24 min-w-0">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <p className="text-sm text-ink" role="status" aria-live="polite">
              Showing {plain(visible.length)} of {plain(results.length)} products
              {results.length !== products.length && <span className="text-ink-muted"> (filtered from {plain(products.length)})</span>}
            </p>
            <div className="flex items-center gap-2">
              <label htmlFor="sort" className="text-sm text-ink-muted">Sort by</label>
              <select id="sort" value={effectiveSort} onChange={(e) => setSort(e.target.value)} className="h-10 rounded border border-line bg-white px-2 text-sm focus:border-brand">
                {searching && <option value="relevance">Best match</option>}
                <option value="az">Name A to Z</option>
                <option value="low">Price: low to high</option>
                <option value="high">Price: high to low</option>
              </select>
            </div>
          </div>

          {results.length === 0 ? (
            <div className="rounded-md border border-line bg-white p-8 text-center">
              <h2 className="text-lg font-semibold">No products found</h2>
              <p className="mt-2 text-sm text-ink-muted">Check the spelling, try fewer words, or remove a filter. A brand or model code on its own often works best.</p>
              <button type="button" onClick={clearAll} className="mt-4 h-10 rounded border border-brand px-4 text-sm font-medium text-brand hover:bg-brand hover:text-white">Clear search and filters</button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {visible.map((p) => <ProductCard key={p.id} product={p} tokens={tokens} onOpen={openPanel} />)}
              </div>
              <Pagination page={current} total={pages} onPage={goPage} />
            </>
          )}
        </section>
      </main>

      {open && <DetailPanel product={open} onClose={closePanel} />}
    </div>
  );
}
