# Product Catalogue

Searchable catalogue built from `generalpricelist220224.pdf` (339 pages). React, Vite and Tailwind. No backend; it works offline after the first load.

## Run

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # static site in dist/
npm run preview    # serve dist/ locally
```

`src/data/products.json` is committed, so the app builds without the PDF or Python.

## Re-generate the data from the PDF

```bash
pip install pdfplumber
npm run extract -- path/to/pricelist.pdf
```

This rewrites `src/data/products.json` and `src/data/parse-report.json`.

### Parse result for the supplied PDF

| Check | Result |
|---|---|
| PDF pages | 339 |
| Data lines found in the PDF (header excluded) | 15,924 |
| Rows parsed | 15,924 |
| Rows that could not be parsed | 0 |
| Products (one per item, 6 down-payment rows each) | 2,709 |
| Items with all instalment columns printed as 0 | 66 (motorcycles); no EMI is shown for them |

2,709 products x 6 rows would be 16,254, so 66 single-row items account for the difference: 2,643 x 6 + 66 x 1 = 15,924.

## What the PDF contains

The PDF is a hire-purchase price list, not a product catalogue. Each item has six rows (down payment 0, 10, 20, 30, 40, 50 percent) with these columns: Item Name, DpOp (down payment %), Price, DP (down payment amount), HP 12/24/36 (total payable) and MI 12/24/36 (monthly instalment).

It has no SKU, brand, category, MRP, discount, stock, warranty, description, specs or image. Those fields are hidden in the app rather than shown blank.

All figures are stored as the strings printed in the PDF. The app only adds thousands separators when displaying them.

### Fields derived from the item name

These are not in the PDF. They are produced by rules in `scripts/extract.py` and can be wrong or missing:

- `category`: keyword rules (for example "REFRIGERATOR" gives Refrigerators & Freezers). 186 items fall under "Other".
- `brand`: first known brand name found in the item name. 509 items have none and show no brand.
- `keySpec`: first capacity or size in the name (for example "1.5 TON", "10 KG").
- `code`: shown only when the name starts with a 4 to 8 digit code such as `601573-`.

Edit the lists at the top of `scripts/extract.py` and re-run to adjust them.

## Search

Fuse.js finds candidates over name, code, brand and category with spaces, case and punctuation removed, so "blue tooth", "Bluetooth" and "BLUE-TOOTH" are equal. Every word is then checked against a spelling allowance: up to 3 letters exact, 4 to 5 letters one edit, 6 or more letters two edits (a swapped pair of letters counts as one). Input is debounced by 150 ms. Matches are ranked by fewest edits, then Fuse score, and matched text is highlighted.

Settings are in `src/config.js` (page size, debounce, currency prefix). The PDF prints numbers with no currency symbol, so none is shown by default.

## Deploy

### GitHub Pages

1. Push this folder to a GitHub repository on the `main` branch.
2. In the repository, open Settings, then Pages, and set Source to "GitHub Actions".
3. The workflow in `.github/workflows/deploy.yml` builds and publishes on every push. The site is served at `https://<user>.github.io/<repo>/`.

### Any static host

Run `npm run build` and upload `dist/`. Asset paths are relative, so it works from a sub-folder. Netlify and Vercel need no extra settings: build command `npm run build`, output folder `dist`.

## Offline use

In production builds a small service worker (`public/sw.js`) caches the app files after the first visit. It needs HTTPS or localhost.

## Android app

`.github/workflows/android.yml` wraps the site with Capacitor and builds a debug APK on GitHub. Run it from the Actions tab (or push to `main`), open the finished run and download the `product-catalogue-apk` artifact. Unzip it and install `app-debug.apk` on the phone (allow "Install unknown apps" for your browser or file manager).

The debug APK is signed with a debug key, which is fine for installing on your own devices. Play Store publishing needs a release keystore.

Locally: `npm run build && npx cap add android && npx cap sync android`, then open the `android` folder in Android Studio.
